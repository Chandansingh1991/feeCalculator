package com.sapient.feeCalculator.exceptions;

/*
 *@author Chandan Singh Karki
 */
public class FileParsingException extends FeeCalculatorBaseException {
    public FileParsingException(String message) {
        super(message);
    }

    public FileParsingException(String message, Throwable cause) {
        super(message, cause);
    }

    public FileParsingException(Throwable cause) {
        super(cause);
    }
}
