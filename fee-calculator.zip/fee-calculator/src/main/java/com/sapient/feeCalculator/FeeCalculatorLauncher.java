package com.sapient.feeCalculator;

import com.sapient.feeCalculator.exceptions.FeeCalculatorBaseException;
import com.sapient.feeCalculator.service.FeeCalculateService;

/*
 *@author Chandan Singh Karki
 */
public class FeeCalculatorLauncher {

    public static void main(String[] args) {
        if (args == null || args.length < 2) {
            System.out.println("Kindly provide valid input parameter--args[0]-> File type and args[1]-> File path");
        }
        String fileType = args[0];  //File type
        String filePath = args[1]; //File path

        try {
            FeeCalculateService.processData(fileType, filePath);
            FeeCalculateService.printData(fileType);
        } catch (FeeCalculatorBaseException e) {
            System.out.println(e.getResponseMessage());
        }


    }
}
