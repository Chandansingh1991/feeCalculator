package com.sapient.feeCalculator.service;

import com.sapient.feeCalculator.constants.MessageConstant;
import com.sapient.feeCalculator.dto.TxnDetails;
import com.sapient.feeCalculator.exceptions.FeeCalculatorBaseException;
import com.sapient.feeCalculator.exceptions.TransactionInputException;
import com.sapient.feeCalculator.service.transaction.AbstractTransactionService;
import com.sapient.feeCalculator.service.transaction.CsvTransactionFileParser;
import com.sapient.feeCalculator.service.transaction.TxtTransactionFileParser;
import com.sapient.feeCalculator.service.transaction.XLSTransactionFileParser;

import java.io.File;
import java.util.List;

/*
 *@author Chandan Singh Karki
 */
public class FeeCalculateService {

    /**
     * FileType enum to hide its detail from external world.
     * It takes two parameter one Type of File and second one is Parser.
     */
    private enum FileType {

        CSV("CSV", new CsvTransactionFileParser()) {
            @Override
            public void process(File file) throws FeeCalculatorBaseException {
                processInternal(this.getTransactionService(), file);
            }

        },
        XLS("XLS", new XLSTransactionFileParser()) {
            @Override
            public void process(File file) throws FeeCalculatorBaseException {
                processInternal(this.getTransactionService(), file);
            }
        },
        TXT("TXT", new TxtTransactionFileParser()) {
            @Override
            public void process(File file) throws FeeCalculatorBaseException {
                processInternal(this.getTransactionService(), file);
            }
        };

        private String fileType;
        private AbstractTransactionService transactionService;

        public String getFileType() {
            return fileType;
        }

        public FileType setFileType(String fileType) {
            this.fileType = fileType;
            return this;
        }

        public AbstractTransactionService getTransactionService() {
            return transactionService;
        }

        public FileType setTransactionService(AbstractTransactionService transactionService) {
            this.transactionService = transactionService;
            return this;
        }

        FileType(String fileType, AbstractTransactionService transactionService) {
            this.fileType = fileType;
            this.transactionService = transactionService;
        }

        public List<TxnDetails> print() {
            return this.getTransactionService().displayTxnReport();
        }

        /**
         * Abstract method overrided by all File Type enums.
         * @param file
         * @throws FeeCalculatorBaseException
         */
        public abstract void process(File file) throws FeeCalculatorBaseException;

        public static FileType getFileTypeByName(String fileType) {
            for (FileType ft : FeeCalculateService.FileType.values()) {
                if (ft.getFileType().equalsIgnoreCase(fileType)) {
                    return ft;
                }
            }
            return null;
        }

        private static void processInternal(AbstractTransactionService abstractTransactionService, File file) throws FeeCalculatorBaseException {
            List<String[]> fields = abstractTransactionService.parseFile(file);
            for (String[] field : fields) {
                TxnDetails txnDetails = abstractTransactionService.getTxnDetails(field);
                abstractTransactionService.addTxn(txnDetails);
            }
        }
    }

    /**
     * This method process data to the desired format.
     *
     * @param fileType tyoe of file CSV,TXT or XLS
     * @param filePath Path of file
     * @throws FeeCalculatorBaseException if File type is invalid or file path is not valid
     */
    public static void processData(String fileType, String filePath) throws FeeCalculatorBaseException {
        FileType ft = FileType.getFileTypeByName(fileType);
        if (ft == null) {
            throw new TransactionInputException(MessageConstant.INVALID_FILE_FORMAT);
        }
        File file = new File(filePath);
        if (file == null || !file.isFile()) {
            throw new TransactionInputException(MessageConstant.FILE_NOT_FOUND);
        }
        ft.process(file);
    }

    /**
     * This method helps to print transaction data data
     *
     * @param fileType
     * @throws FeeCalculatorBaseException
     */
    public static List<TxnDetails> printData(String fileType) throws FeeCalculatorBaseException {
        FileType ft = FileType.getFileTypeByName(fileType);
        if (ft == null) {
            throw new TransactionInputException(MessageConstant.INVALID_FILE_FORMAT);
        }
        return ft.print();
    }

}
