package com.sapient.feeCalculator.service.transaction;

import java.io.File;
import java.util.List;

/*
 *@author Chandan Singh Karki
 */
public class XLSTransactionFileParser extends AbstractTransactionService {
    @Override
    public List<String[]> parseFile(File file) {
        return null;
    }
}
