package com.sapient.feeCalculator.dto;

import java.io.Serializable;
import java.util.Date;

/*
 *@author Chandan Singh Karki
 */
public class TxnDetails implements Serializable {
    private static final long serialVersionUID=1l;

    private String txnId; //external transaction id
    private String clientId; //client id
    private String securityId; //security id
    private Integer txnType; // txn type
    private Date date; //date of transaction
    private Double value; //current market value
    private Boolean priority;//True:Normal | False: High
    private Double fees; //fee calculated on priority and intraday

    public String getTxnId() {
        return txnId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getSecurityId() {
        return securityId;
    }

    public Integer getTxnType() {
        return txnType;
    }

    public Date getDate() {
        return date;
    }

    public Double getValue() {
        return value;
    }

    public Boolean getPriority() {
        return priority;
    }

    public Double getFees() {
        return fees;
    }

    public TxnDetails setFees(Double fees) {
        this.fees = fees;
        return this;
    }

    private TxnDetails(TxnDetailBuilder TxnDetailBuilder) {
        this.txnId = TxnDetailBuilder.getTxnId();
        this.clientId = TxnDetailBuilder.getClientId();
        this.securityId = TxnDetailBuilder.getSecurityId();
        this.txnType = TxnDetailBuilder.getTxnType();
        this.date = TxnDetailBuilder.getDate();
        this.value = TxnDetailBuilder.getValue();
        this.priority = TxnDetailBuilder.getPriority();
        this.fees = TxnDetailBuilder.getFees();
    }


    public static class TxnDetailBuilder {
        private String txnId;
        private String clientId;
        private String securityId;
        private Integer txnType;
        private Date date;
        private Double value;
        private Boolean priority;
        private Double fees;

        public String getTxnId() {
            return txnId;
        }

        public TxnDetailBuilder setTxnId(String txnId) {
            this.txnId = txnId;
            return this;
        }

        public String getClientId() {
            return clientId;
        }

        public TxnDetailBuilder setClientId(String clientId) {
            this.clientId = clientId;
            return this;
        }

        public String getSecurityId() {
            return securityId;
        }

        public TxnDetailBuilder setSecurityId(String securityId) {
            this.securityId = securityId;
            return this;
        }

        public Integer getTxnType() {
            return txnType;
        }

        public TxnDetailBuilder setTxnType(Integer txnType) {
            this.txnType = txnType;
            return this;
        }

        public Date getDate() {
            return date;
        }

        public TxnDetailBuilder setDate(Date date) {
            this.date = date;
            return this;
        }

        public Double getValue() {
            return value;
        }

        public TxnDetailBuilder setValue(Double value) {
            this.value = value;
            return this;
        }

        public Boolean getPriority() {
            return priority;
        }

        public TxnDetailBuilder setPriority(Boolean priority) {
            this.priority = priority;
            return this;
        }

        public Double getFees() {
            return fees;
        }

        public TxnDetailBuilder setFees(Double fees) {
            this.fees = fees;
            return this;
        }

        public TxnDetails build() {
            return new TxnDetails(this);
        }
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TxnDetails{");
        sb.append("clientId='").append(clientId).append('\'');
        sb.append(", date=").append(date);
        sb.append(", fees=").append(fees);
        sb.append(", priority=").append(priority);
        sb.append(", securityId='").append(securityId).append('\'');
        sb.append(", txnId='").append(txnId).append('\'');
        sb.append(", txnType=").append(txnType);
        sb.append(", value=").append(value);
        sb.append('}');
        return sb.toString();
    }
}
