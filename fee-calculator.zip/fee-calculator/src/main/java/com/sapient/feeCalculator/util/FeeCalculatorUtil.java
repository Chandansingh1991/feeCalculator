package com.sapient.feeCalculator.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/*
 *@author chandan singh karki
 */
public class FeeCalculatorUtil {
    /**
     *
     * @param value
     * @return
     */
    public static Double parseValue(String value) {
        try{
            return Double.parseDouble(value);
        }catch(Exception ex){
            return (double) 0;
        }
    }

    /**
     *
     * @param priority
     * @return
     */
    public static Boolean getBooleanValue(String priority) {
        if(priority!= null){
            priority = priority.trim();
            if(priority.equalsIgnoreCase("y")){
                return true;
            } else {
                return false;
            }
        }else{
            return false;
        }
    }

    /**
     *
     * @param date
     * @return
     */
    public static Date parseDate(String date) {
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date convDate = sdf.parse(date);
            return convDate;
        }catch(Exception  ex){
            return null;
        }
    }
}
