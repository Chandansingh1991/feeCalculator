package com.sapient.feeCalculator.constants;

/*
 *@author Chandan Singh Karki
 */
public class FeeCalculatorConstant {

    public static final String TXT_SPLITTOR=",";
    public static final String CSV_SPLITTOR=",";

    public enum TXN_FEES {
        TEN(10),
        FIFTY(50),
        HUNDRED(100),
        FIVE_HUNDRED(500);
        private double fees;
        TXN_FEES(double fees) {
            this.fees = fees;
        }
        public double getFees() {
            return fees;
        }
    };

    public enum TXN_TYPE {
        BUY("BUY",1),
        SELL("SELL",2),
        DEPOSIT("DEPOSIT",3),
        WITHDRAW("WITHDRAW",4);
        private int type;
        private String name;
        TXN_TYPE(String name, int type) {
            this.name = name;
            this.type = type;
        }

        public int getType() {
            return type;
        }
        public String getName(){
            return  name;
        }

        public static TXN_TYPE getTxnTypeByName(String name){
            for(TXN_TYPE txn_type:TXN_TYPE.values()){
                if(txn_type.getName().equalsIgnoreCase(name)){
                    return txn_type;
                }
            }
            return null;
        }

        public static TXN_TYPE getTxnTypeByType(int type){
            for(TXN_TYPE txn_type:TXN_TYPE.values()){
                if(txn_type.getType()==type){
                    return txn_type;
                }
            }
            return null;
        }
    };

}
