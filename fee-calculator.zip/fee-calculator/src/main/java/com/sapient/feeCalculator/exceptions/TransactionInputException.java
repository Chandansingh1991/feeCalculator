package com.sapient.feeCalculator.exceptions;

/*
 *@author Chandan Singh Karki
 */
public class TransactionInputException extends FeeCalculatorBaseException {
    public TransactionInputException(String message) {
        super(message);
    }

    public TransactionInputException(String message, Throwable cause) {
        super(message, cause);
    }

    public TransactionInputException(Throwable cause) {
        super(cause);
    }
}
