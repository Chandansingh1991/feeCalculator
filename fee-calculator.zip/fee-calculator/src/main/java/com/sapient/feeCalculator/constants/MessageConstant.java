package com.sapient.feeCalculator.constants;

/*
 *@author Chandan Singh Karki
 */
public interface MessageConstant {
    public static final String INVALID_FILE_FORMAT="Application don't support Input file format...Kindly prov";
    public static final String FILE_NOT_FOUND="Input file not present in System";
    public static final String FILE_PARSING_ERROR="Exception while parsing file";

}
