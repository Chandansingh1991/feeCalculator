package com.sapient.feeCalculator.service.transaction;

import com.sapient.feeCalculator.constants.FeeCalculatorConstant;
import com.sapient.feeCalculator.dto.TxnDetails;
import com.sapient.feeCalculator.exceptions.FileParsingException;
import com.sapient.feeCalculator.util.FeeCalculatorUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*
 *Abstract Transaction service for populating transaction
 *@author Chandan Singh Karki
 */
public abstract class AbstractTransactionService {

    private List<TxnDetails> txnDetailsList;

    public List<TxnDetails> getTxnDetailsList() {
        return txnDetailsList;
    }

    public abstract List<String[]> parseFile(File file) throws FileParsingException;

    /**
     * This method will transform input data into TxnDetail Object
     *
     * @param data String[]
     * @return TxnDetails Object
     */
    public TxnDetails getTxnDetails(String[] data) {

        if (data == null || data.length < 7) {
            return null;
        }

        TxnDetails.TxnDetailBuilder txnDetailBuilder = new TxnDetails.TxnDetailBuilder();
        txnDetailBuilder.setTxnId(data[0]).setClientId(data[1]).setSecurityId(data[2]);
        FeeCalculatorConstant.TXN_TYPE txnType = FeeCalculatorConstant.TXN_TYPE.getTxnTypeByName(data[3]);
        if (txnType != null) {
            txnDetailBuilder.setTxnType(txnType.getType());
        } else {
            txnDetailBuilder.setTxnType(0);
        }
        txnDetailBuilder.setDate(FeeCalculatorUtil.parseDate(data[4]))
                .setValue(FeeCalculatorUtil.parseValue(data[5]))
                .setPriority(FeeCalculatorUtil.getBooleanValue(data[6]));
        txnDetailBuilder = calculateTransactionFee(txnDetailBuilder);
        return txnDetailBuilder.build();

    }

    /**Adding txnDetail Object to list
     * @param txnDetails
     */
    public void addTxn(TxnDetails txnDetails) {

        if (txnDetails == null) {
            return;
        }

        if (getTxnDetailsList() == null) {
            txnDetailsList = new ArrayList<>();
        }

        txnDetailsList.add(txnDetails);

    }

    /**
     * calculate fees on the basis of conditions
     * @param txnDetailBuilder
     * @return
     */
    private TxnDetails.TxnDetailBuilder calculateTransactionFee(TxnDetails.TxnDetailBuilder txnDetailBuilder) {
        if (isIntraTransaction(txnDetailBuilder)) {
            txnDetailBuilder.setFees(FeeCalculatorConstant.TXN_FEES.TEN.getFees());
        } else {

            if (txnDetailBuilder.getPriority()) {
                txnDetailBuilder.setFees(FeeCalculatorConstant.TXN_FEES.FIVE_HUNDRED.getFees());

            } else {
                if (txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.WITHDRAW.getType() ||
                        txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.SELL.getType()) {

                    txnDetailBuilder.setFees(FeeCalculatorConstant.TXN_FEES.HUNDRED.getFees());

                } else if (txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.DEPOSIT.getType() ||
                        txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.BUY.getType()) {

                    txnDetailBuilder.setFees(FeeCalculatorConstant.TXN_FEES.FIFTY.getFees());
                }

            }

        }
        return txnDetailBuilder;
    }

    /**
     * This method will check whether the transaction is intra or not
     *
     * @param txnDetailBuilder
     * @return
     */
    private boolean isIntraTransaction(TxnDetails.TxnDetailBuilder txnDetailBuilder) {
        boolean isIntraTransaction = false;
        if (getTxnDetailsList() != null && !getTxnDetailsList().isEmpty()) {
            for (TxnDetails txn : getTxnDetailsList()) {

                if (txn.getClientId().equals(txnDetailBuilder.getClientId()) &&
                        txn.getSecurityId().equals(txnDetailBuilder.getSecurityId()) &&
                        txn.getDate().equals(txnDetailBuilder.getDate())) {

                    if ((txn.getTxnType() == FeeCalculatorConstant.TXN_TYPE.SELL.getType() &&
                            txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.BUY.getType()) ||
                            (txn.getTxnType() == FeeCalculatorConstant.TXN_TYPE.BUY.getType() &&
                                    txnDetailBuilder.getTxnType() == FeeCalculatorConstant.TXN_TYPE.SELL.getType())) {
                        isIntraTransaction = true;
                        txn.setFees(FeeCalculatorConstant.TXN_FEES.TEN.getFees());
                        break;
                    }
                }

            }
        }

        return isIntraTransaction;
    }

    /**
     *This method will print report after sorting on some parameters
     */
    public List<TxnDetails> displayTxnReport() {
        if (getTxnDetailsList() != null && !getTxnDetailsList().isEmpty()) {
            getTxnDetailsList().sort(Comparator.comparing(TxnDetails::getClientId)
                    .thenComparing(TxnDetails::getTxnType)
                    .thenComparing(TxnDetails::getDate)
                    .thenComparing(TxnDetails::getPriority));

            System.out.println("ClientId | Transaction type | Transaction date | Priority |Fees");
            for (TxnDetails txnDetails : getTxnDetailsList()) {
                System.out.println(txnDetails.getClientId() + "|" + FeeCalculatorConstant.TXN_TYPE.getTxnTypeByType(txnDetails.getTxnType()).getName() + "|" + txnDetails.getDate() + "|" + (txnDetails.getPriority() ? "HIGH" : "MEDIUM") + "|" + txnDetails.getFees());
            }
        }
        return getTxnDetailsList();
    }

}
