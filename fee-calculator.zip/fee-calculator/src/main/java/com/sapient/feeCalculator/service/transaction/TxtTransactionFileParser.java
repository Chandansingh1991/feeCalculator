package com.sapient.feeCalculator.service.transaction;

import com.sapient.feeCalculator.constants.FeeCalculatorConstant;
import com.sapient.feeCalculator.constants.MessageConstant;
import com.sapient.feeCalculator.exceptions.FileParsingException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 *@author Chandan Singh Karki
 */
public class TxtTransactionFileParser extends AbstractTransactionService {

    @Override
    public List<String[]> parseFile(File file) throws FileParsingException {
        String line = "";
        List<String[]> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(FeeCalculatorConstant.TXT_SPLITTOR);
                list.add(fields);
            }
        } catch (Exception e) {
            throw new FileParsingException(MessageConstant.FILE_PARSING_ERROR, e.getCause());
        }
        return list;
    }
}
