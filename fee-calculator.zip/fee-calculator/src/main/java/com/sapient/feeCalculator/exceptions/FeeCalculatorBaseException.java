package com.sapient.feeCalculator.exceptions;

/*
 *@author Chandan Singh Karki
 */
public class FeeCalculatorBaseException extends Exception {

    private String responseMessage;

    public String getResponseMessage() {
        return responseMessage;
    }

    public FeeCalculatorBaseException setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
        return this;
    }

    public FeeCalculatorBaseException(String message) {
        super(message);
        this.responseMessage=message;
    }

    public FeeCalculatorBaseException(String message, Throwable cause) {
        super(message, cause);
        this.responseMessage=message;
    }

    public FeeCalculatorBaseException(Throwable cause) {
        super(cause);
    }

}
