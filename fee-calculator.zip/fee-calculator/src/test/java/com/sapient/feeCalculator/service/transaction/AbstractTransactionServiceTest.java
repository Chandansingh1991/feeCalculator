package com.sapient.feeCalculator.service.transaction;

import com.sapient.feeCalculator.constants.FeeCalculatorConstant;
import com.sapient.feeCalculator.dto.TxnDetails;
import com.sapient.feeCalculator.util.FeeCalculatorUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class AbstractTransactionServiceTest {

    private TxnDetails txnDetails;

    @Before
    public void init() {
        TxnDetails.TxnDetailBuilder txnDetailBuilder = new TxnDetails.TxnDetailBuilder();
        txnDetailBuilder.setTxnId("123").setClientId("1").setSecurityId("123");
        FeeCalculatorConstant.TXN_TYPE txnType = FeeCalculatorConstant.TXN_TYPE.getTxnTypeByName("BUY");
        if (txnType != null) {
            txnDetailBuilder.setTxnType(txnType.getType());
        } else {
            txnDetailBuilder.setTxnType(0);
        }
        txnDetailBuilder.setDate(FeeCalculatorUtil.parseDate("07|25|2019"))
                .setValue(2.0)
                .setPriority(true).setFees(2.0);
        txnDetails = txnDetailBuilder.build();
    }

    @Test
    public void getTxnDetailsForHighPriority() {

        String[] input = {"SAPEXTXN1", "GS", "ICICI", "BUY", "23/11/2013", "101.9", "Y"};
        AbstractTransactionService abstractTransactionService = new CsvTransactionFileParser();
        TxnDetails txnDetails = abstractTransactionService.getTxnDetails(input);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.FIVE_HUNDRED.getFees(), txnDetails.getFees(), 0);
        Assert.assertTrue(txnDetails.getPriority());
    }

    @Test
    public void getTxnDetailsForWithdrawOrSell() {

        String[] input = {"SAPEXTXN1", "GS", "ICICI", "WITHDRAW", "23/11/2013", "101.9", "N"};
        AbstractTransactionService abstractTransactionService = new CsvTransactionFileParser();
        TxnDetails txnDetails = abstractTransactionService.getTxnDetails(input);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.HUNDRED.getFees(), txnDetails.getFees(), 0);

        String[] input1 = {"SAPEXTXN1", "GS", "ICICI", "SELL", "23/11/2013", "101.9", "N"};
        abstractTransactionService = new CsvTransactionFileParser();
        txnDetails = abstractTransactionService.getTxnDetails(input1);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.HUNDRED.getFees(), txnDetails.getFees(), 0);
    }

    @Test
    public void getTxnDetailsForIntra() {

        String[] input = {"SAPEXTXN1", "GS", "ICICI", "BUY", "23/11/2013", "101.9", "N"};
        String[] input1 = {"SAPEXTXN1", "GS", "ICICI", "SELL", "23/11/2013", "101.9", "N"};

        AbstractTransactionService abstractTransactionService = new CsvTransactionFileParser();
        TxnDetails txnDetails = abstractTransactionService.getTxnDetails(input);
        abstractTransactionService.addTxn(txnDetails);
        txnDetails=abstractTransactionService.getTxnDetails(input1);
        abstractTransactionService.addTxn(txnDetails);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.TEN.getFees(), abstractTransactionService.getTxnDetailsList().get(0).getFees(), 0);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.TEN.getFees(), abstractTransactionService.getTxnDetailsList().get(0).getFees(), 0);
    }

    @Test
    public void getTxnDetailsForDepositeOrBuy() {

        String[] input1 = {"SAPEXTXN1", "GS", "ICICI", "BUY", "23/11/2013", "101.9", "N"};
        AbstractTransactionService abstractTransactionService = new CsvTransactionFileParser();
        TxnDetails txnDetails = abstractTransactionService.getTxnDetails(input1);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.FIFTY.getFees(), txnDetails.getFees(), 0);

        String[] input2 = {"SAPEXTXN1", "GS", "ICICI", "DEPOSITE", "23/11/2013", "101.9", "N"};
        abstractTransactionService = new CsvTransactionFileParser();
        abstractTransactionService.getTxnDetails(input2);
        Assert.assertEquals(FeeCalculatorConstant.TXN_FEES.FIFTY.getFees(), txnDetails.getFees(), 0);
    }



    @Test
    public void addTxn() {
        AbstractTransactionService abstractTransactionService = new CsvTransactionFileParser();
        abstractTransactionService.addTxn(null);
        Assert.assertNull(abstractTransactionService.getTxnDetailsList());
        abstractTransactionService.addTxn(txnDetails);
        Assert.assertNotNull(abstractTransactionService.getTxnDetailsList());
        Assert.assertTrue(abstractTransactionService.getTxnDetailsList().size() == 1);
        Assert.assertEquals(txnDetails, abstractTransactionService.getTxnDetailsList().get(0));

    }

    @Test
    public void displayTxnReport() {
    }
}