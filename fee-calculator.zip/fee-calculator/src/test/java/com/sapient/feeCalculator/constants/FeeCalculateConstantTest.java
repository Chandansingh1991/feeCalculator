package com.sapient.feeCalculator.constants;

import org.junit.Assert;
import org.junit.Test;


public class FeeCalculateConstantTest {

    @Test
    public void testForCsvAndTextSplittor() {
        Assert.assertEquals(",", FeeCalculatorConstant.CSV_SPLITTOR);
        Assert.assertEquals(",", FeeCalculatorConstant.TXT_SPLITTOR);
    }

    @Test
    public void testTxnFees(){
        Assert.assertEquals(10,FeeCalculatorConstant.TXN_FEES.TEN.getFees(),0);
        Assert.assertEquals(50,FeeCalculatorConstant.TXN_FEES.FIFTY.getFees(),0);
        Assert.assertEquals(100,FeeCalculatorConstant.TXN_FEES.HUNDRED.getFees(),0);
        Assert.assertEquals(500,FeeCalculatorConstant.TXN_FEES.FIVE_HUNDRED.getFees(),0);
    }

    @Test
    public void testTxnType(){
        Assert.assertEquals("BUY",FeeCalculatorConstant.TXN_TYPE.BUY.getName());
        Assert.assertEquals("SELL",FeeCalculatorConstant.TXN_TYPE.SELL.getName());
        Assert.assertEquals("WITHDRAW",FeeCalculatorConstant.TXN_TYPE.WITHDRAW.getName());
        Assert.assertEquals("DEPOSIT",FeeCalculatorConstant.TXN_TYPE.DEPOSIT.getName());

        Assert.assertEquals(1,FeeCalculatorConstant.TXN_TYPE.BUY.getType());
        Assert.assertEquals(2,FeeCalculatorConstant.TXN_TYPE.SELL.getType());
        Assert.assertEquals(3,FeeCalculatorConstant.TXN_TYPE.DEPOSIT.getType());
        Assert.assertEquals(4,FeeCalculatorConstant.TXN_TYPE.WITHDRAW.getType());

    }

    @Test
    public void testGetTxnTypeByName(){
        Assert.assertEquals(FeeCalculatorConstant.TXN_TYPE.BUY,FeeCalculatorConstant.TXN_TYPE.getTxnTypeByName("buy"));
        Assert.assertEquals(FeeCalculatorConstant.TXN_TYPE.BUY,FeeCalculatorConstant.TXN_TYPE.getTxnTypeByName("BUY"));
        Assert.assertNull(FeeCalculatorConstant.TXN_TYPE.getTxnTypeByName("chandan"));
    }

    @Test
    public void testGetTxnTypeByType(){
        Assert.assertEquals(FeeCalculatorConstant.TXN_TYPE.BUY,FeeCalculatorConstant.TXN_TYPE.getTxnTypeByType(1));
        Assert.assertEquals(FeeCalculatorConstant.TXN_TYPE.BUY,FeeCalculatorConstant.TXN_TYPE.getTxnTypeByType(1));
        Assert.assertNull(FeeCalculatorConstant.TXN_TYPE.getTxnTypeByType(10));
    }

}
