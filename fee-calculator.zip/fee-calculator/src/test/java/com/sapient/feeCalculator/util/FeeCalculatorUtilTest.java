package com.sapient.feeCalculator.util;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class FeeCalculatorUtilTest {

    @Test
    public void parseValue() {
        Assert.assertEquals(1.0,FeeCalculatorUtil.parseValue("1"),0);
        Assert.assertEquals(0,FeeCalculatorUtil.parseValue("abc"),0);
    }

    @Test
    public void getBooleanValue() {
        Assert.assertTrue(FeeCalculatorUtil.getBooleanValue("Y"));
        Assert.assertFalse(FeeCalculatorUtil.getBooleanValue("N"));
        Assert.assertFalse(FeeCalculatorUtil.getBooleanValue(""));
    }

    @Test
    public void parseDate() {
        Assert.assertNotNull(FeeCalculatorUtil.parseDate("11/22/2013"));
        Assert.assertNull(FeeCalculatorUtil.parseDate("11-22-2013"));
        Assert.assertNull(FeeCalculatorUtil.parseDate(null));

    }
}