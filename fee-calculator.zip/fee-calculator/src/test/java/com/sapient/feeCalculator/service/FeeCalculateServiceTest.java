package com.sapient.feeCalculator.service;

import com.sapient.feeCalculator.constants.MessageConstant;
import com.sapient.feeCalculator.exceptions.FeeCalculatorBaseException;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class FeeCalculateServiceTest {

    @Test
    public void processData() {
        try {
            FeeCalculateService.processData("dummy", "");
        } catch (FeeCalculatorBaseException e) {
            Assert.assertEquals(MessageConstant.INVALID_FILE_FORMAT, e.getResponseMessage());
        }

        try {
            FeeCalculateService.processData("CSV", "");
        } catch (FeeCalculatorBaseException e) {
            Assert.assertEquals(MessageConstant.FILE_NOT_FOUND, e.getResponseMessage());
        }

        try {
            FeeCalculateService.processData("CSV", "src/main/resources/input.csv");
            Assert.assertEquals(20, FeeCalculateService.printData("CSV").size());
        } catch (FeeCalculatorBaseException e) {
        }


    }

    @Test
    public void printData() {
        try {
            FeeCalculateService.printData("dummy");
        } catch (FeeCalculatorBaseException e) {
            Assert.assertEquals(MessageConstant.INVALID_FILE_FORMAT, e.getResponseMessage());
        }
    }
}