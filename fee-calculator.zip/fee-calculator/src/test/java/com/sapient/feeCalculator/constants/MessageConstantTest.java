package com.sapient.feeCalculator.constants;

import org.junit.Assert;
import org.junit.Test;

public class MessageConstantTest {

    @Test
    public void testForValues() {
        Assert.assertEquals("Exception while parsing file",MessageConstant.FILE_PARSING_ERROR);
        Assert.assertEquals("Input file not present in System",MessageConstant.FILE_NOT_FOUND);
        Assert.assertEquals("Application don't support Input file format...Kindly prov",MessageConstant.INVALID_FILE_FORMAT);
    }
}
