package com.sapient.feeCalculator.dto;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class TxnDetailsTest {

    @Test
    public void testTxnDetailObject() {
        TxnDetails.TxnDetailBuilder detailBuilder = new TxnDetails.TxnDetailBuilder();
        detailBuilder.setClientId("1").setDate(new Date()).setFees(1.0).setValue(1.0).setTxnId("1").setPriority(true);
        TxnDetails txnDetails = detailBuilder.build();
        Assert.assertNotNull(txnDetails);
    }
}
