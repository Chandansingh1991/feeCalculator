Fee-Caculator Application has exposed two method "processData" for processing input file
and "printData" for printing the transaction data.

FeeCaclulator is Launch pad of this application where you can run the program afer passing the java
runtime arguement i.e FILE_TYPE and File path.
